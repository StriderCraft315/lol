# Proxmox Cloud Platform - Enterprise Cloud VPS Hosting Solution

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Python](https://img.shields.io/badge/python-3.9+-green.svg)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104.0-009688.svg)
![License](https://img.shields.io/badge/license-Proprietary-red.svg)
![Status](https://img.shields.io/badge/status-Production%20Ready-brightgreen.svg)

## 🚀 Overview

Proxmox Cloud Platform is a complete, production-ready cloud VPS hosting solution similar to DigitalOcean, Hetzner Cloud, or AWS Lightsail. Built with Python FastAPI backend and modern React frontend, it provides automated VPS deployment, multi-node infrastructure, reseller hosting, multiple payment gateways, and enterprise cloud features.

## ✨ Features

### Core Features
- **Automated VPS Deployment** - Deploy KVM virtual machines and LXC containers instantly
- **Multi-Node Infrastructure** - Support unlimited Proxmox nodes with automatic load balancing
- **Role-Based Access Control** - 7 hierarchical roles (OWNER, CO-OWNER, CEO, MANAGER, MAIN_ADMIN, ADMIN, MEMBER)
- **Hourly Billing System** - Pay-as-you-go with automatic hourly deductions
- **Internal Wallet System** - Coin-based billing system with multiple funding options

### Payment Gateways
- 💳 **Stripe** - Credit card payments
- 💰 **PayPal** - PayPal wallet payments
- 🏦 **Razorpay** - Indian payment gateway
- 🔗 **OxaPay** - Cryptocurrency payments
- ₿ **Crypto** - Bitcoin, Ethereum, Litecoin, USDT

### Security Features
- **JWT Authentication** with refresh tokens
- **Two-Factor Authentication (2FA)**
- **Cloudflare Integration** - DDoS protection and firewall rules
- **Anti-Abuse System** - Detect and prevent abuse
- **Rate Limiting** - API rate limiting per user

### Business Features
- **Reseller System** - Allow users to become resellers
- **Affiliate Program** - Referral commissions
- **Coupon System** - Discount codes with usage limits
- **Public REST API** - Complete API for external services
- **Server Marketplace** - Browse and select VPS plans
- **Discord Integration** - Webhook logging and admin bot

### Admin Features
- **Complete Payment Gateway Management** - Enable/disable, configure, test
- **User Management** - Create, edit, delete users with role assignment
- **Node Management** - Add/remove Proxmox nodes, monitor health
- **Plan Management** - Create and manage VPS plans
- **Audit Logs** - Track all admin actions
- **Branding Control** - Customize panel appearance

## 📋 Prerequisites

### System Requirements
- **Operating System**: Ubuntu 20.04 LTS or 22.04 LTS
- **CPU**: 2+ cores (4+ recommended)
- **RAM**: 4GB minimum (8GB+ recommended)
- **Storage**: 20GB+ free space
- **Network**: Static IP address

### Software Requirements
- Python 3.9 or higher
- PostgreSQL 12+
- Redis 6+
- Nginx
- Git

## 🔧 Installation

### Quick Installation (Recommended)

```bash
# Download the installer
wget https://raw.githubusercontent.com/your-repo/proxmox-cloud/main/setup.sh
chmod +x setup.sh

# Run the automatic installation
sudo ./setup.sh