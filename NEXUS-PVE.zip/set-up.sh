#!/bin/bash

# =============================================================================
# Proxmox Cloud Platform - Automatic Installation Script
# Version: 1.0.0
# Description: Complete automated setup for Proxmox Cloud Platform
# =============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="proxmox-cloud"
APP_USER="proxmox"
APP_GROUP="proxmox"
APP_DIR="/opt/proxmox-cloud"
DATA_DIR="/var/lib/proxmox-cloud"
LOG_DIR="/var/log/proxmox-cloud"
CONFIG_DIR="/etc/proxmox-cloud"
VENV_DIR="${APP_DIR}/venv"
PORT=8000
HOST="0.0.0.0"

# Log file
LOG_FILE="${LOG_DIR}/install.log"

# =============================================================================
# Helper Functions
# =============================================================================

print_header() {
    echo -e "${BLUE}"
    echo "================================================================================"
    echo "  $1"
    echo "================================================================================"
    echo -e "${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}➜ $1${NC}"
}

check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. Creating non-root user for the application..."
    fi
}

create_log_file() {
    mkdir -p "$LOG_DIR"
    touch "$LOG_FILE"
    chmod 644 "$LOG_FILE"
    exec 2> >(tee -a "$LOG_FILE" >&2)
    exec > >(tee -a "$LOG_FILE")
}

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# =============================================================================
# System Checks and Updates
# =============================================================================

check_os() {
    print_header "Checking Operating System"
    
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        print_success "OS: $OS $VER"
        
        if [[ "$OS" != "Ubuntu" ]] || [[ "$VER" != "22.04" && "$VER" != "20.04" ]]; then
            print_warning "This script is optimized for Ubuntu 20.04/22.04. Continuing anyway..."
        fi
    else
        print_warning "Cannot detect OS. Continuing anyway..."
    fi
    log "OS: $OS $VER"
}

check_requirements() {
    print_header "Checking System Requirements"
    
    # Check RAM
    total_ram=$(free -m | awk '/^Mem:/{print $2}')
    if [ $total_ram -lt 1024 ]; then
        print_warning "System has less than 1GB RAM. Minimum recommended is 2GB."
    else
        print_success "RAM: ${total_ram}MB"
    fi
    
    # Check Disk Space
    available_disk=$(df -BG / | awk 'NR==2 {print $4}' | sed 's/G//')
    if [ $available_disk -lt 10 ]; then
        print_error "Less than 10GB disk space available. Need at least 10GB."
        exit 1
    else
        print_success "Disk Space: ${available_disk}GB available"
    fi
    
    # Check CPU
    cpu_cores=$(nproc)
    print_success "CPU Cores: $cpu_cores"
    
    log "System: ${total_ram}MB RAM, ${available_disk}GB Disk, ${cpu_cores} CPU Cores"
}

update_system() {
    print_header "Updating System Packages"
    
    print_info "Updating package list..."
    apt-get update -y >> "$LOG_FILE" 2>&1
    
    print_info "Upgrading packages..."
    apt-get upgrade -y >> "$LOG_FILE" 2>&1
    
    print_success "System updated successfully"
    log "System packages updated"
}

install_dependencies() {
    print_header "Installing System Dependencies"
    
    local packages=(
        python3
        python3-pip
        python3-venv
        python3-dev
        postgresql
        postgresql-contrib
        redis-server
        nginx
        supervisor
        git
        curl
        wget
        build-essential
        libpq-dev
        libssl-dev
        libffi-dev
        libxml2-dev
        libxslt1-dev
        libjpeg-dev
        zlib1g-dev
        libpng-dev
        ufw
        fail2ban
        certbot
        python3-certbot-nginx
    )
    
    for package in "${packages[@]}"; do
        print_info "Installing $package..."
        apt-get install -y "$package" >> "$LOG_FILE" 2>&1
    done
    
    print_success "All system dependencies installed"
    log "System dependencies installed"
}

# =============================================================================
# User and Directory Setup
# =============================================================================

create_user() {
    print_header "Creating Application User"
    
    if id "$APP_USER" &>/dev/null; then
        print_warning "User $APP_USER already exists"
    else
        useradd -m -s /bin/bash "$APP_USER"
        print_success "User $APP_USER created"
    fi
    
    # Create directories
    mkdir -p "$APP_DIR" "$DATA_DIR" "$LOG_DIR" "$CONFIG_DIR"
    chown -R "$APP_USER:$APP_GROUP" "$APP_DIR" "$DATA_DIR" "$LOG_DIR" "$CONFIG_DIR"
    chmod 755 "$APP_DIR" "$DATA_DIR" "$LOG_DIR" "$CONFIG_DIR"
    
    print_success "Directories created"
    log "User and directories created"
}

# =============================================================================
# Database Setup
# =============================================================================

setup_postgresql() {
    print_header "Setting up PostgreSQL Database"
    
    # Start PostgreSQL
    systemctl start postgresql >> "$LOG_FILE" 2>&1
    systemctl enable postgresql >> "$LOG_FILE" 2>&1
    
    # Create database and user
    sudo -u postgres psql << EOF >> "$LOG_FILE" 2>&1
    CREATE DATABASE proxmox_cloud;
    CREATE USER proxmox_user WITH PASSWORD 'proxmox_password_2024';
    GRANT ALL PRIVILEGES ON DATABASE proxmox_cloud TO proxmox_user;
    ALTER USER proxmox_user CREATEDB;
    \c proxmox_cloud
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    CREATE EXTENSION IF NOT EXISTS "pgcrypto";
EOF
    
    print_success "PostgreSQL database configured"
    log "PostgreSQL setup completed"
    
    # Create backup script
    cat > /etc/cron.daily/proxmox-db-backup << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/proxmox-cloud"
mkdir -p $BACKUP_DIR
pg_dump -U proxmox_user proxmox_cloud > "$BACKUP_DIR/proxmox_cloud_$(date +%Y%m%d).sql"
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
EOF
    chmod +x /etc/cron.daily/proxmox-db-backup
}

setup_redis() {
    print_header "Setting up Redis"
    
    systemctl start redis-server >> "$LOG_FILE" 2>&1
    systemctl enable redis-server >> "$LOG_FILE" 2>&1
    
    print_success "Redis configured"
    log "Redis setup completed"
}

# =============================================================================
# Application Setup
# =============================================================================

setup_application() {
    print_header "Installing Proxmox Cloud Platform"
    
    # Copy application files
    print_info "Copying application files..."
    cp -r ./* "$APP_DIR/"
    chown -R "$APP_USER:$APP_GROUP" "$APP_DIR"
    
    # Create virtual environment
    print_info "Creating Python virtual environment..."
    su - "$APP_USER" -c "cd $APP_DIR && python3 -m venv $VENV_DIR" >> "$LOG_FILE" 2>&1
    
    # Install Python packages
    print_info "Installing Python packages..."
    su - "$APP_USER" -c "cd $APP_DIR && $VENV_DIR/bin/pip install --upgrade pip" >> "$LOG_FILE" 2>&1
    su - "$APP_USER" -c "cd $APP_DIR && $VENV_DIR/bin/pip install -r requirements.txt" >> "$LOG_FILE" 2>&1
    
    # Create environment file
    print_info "Creating environment configuration..."
    cat > "$CONFIG_DIR/.env" << EOF
# Database Configuration
DATABASE_URL=postgresql://proxmox_user:proxmox_password_2024@localhost:5432/proxmox_cloud

# Security
SECRET_KEY=$(openssl rand -hex 32)
JWT_SECRET_KEY=$(openssl rand -hex 32)

# Admin Configuration
ADMIN_EMAIL=admin@proxmoxcloud.com
ADMIN_PASSWORD=Admin@123456
ADMIN_USERNAME=admin

# System Configuration
DEFAULT_COIN_RATE=1.0
HOURLY_BILLING_INTERVAL=3600
GRACE_PERIOD_DAYS=7
PANEL_NAME=Proxmox Cloud Platform
PRIMARY_COLOR=#3B82F6

# Redis
REDIS_URL=redis://localhost:6379

# Payment Gateways (Configure via Admin Panel)
STRIPE_API_KEY=
STRIPE_WEBHOOK_SECRET=
PAYPAL_CLIENT_ID=
PAYPAL_CLIENT_SECRET=
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
OXAPAY_API_KEY=
CRYPTO_WALLET_BTC=
CRYPTO_WALLET_ETH=
CRYPTO_WALLET_LTC=
CRYPTO_WALLET_USDT=
EOF
    
    chown "$APP_USER:$APP_GROUP" "$CONFIG_DIR/.env"
    chmod 600 "$CONFIG_DIR/.env"
    
    # Create symbolic link
    ln -sf "$CONFIG_DIR/.env" "$APP_DIR/.env"
    
    print_success "Application files installed"
    log "Application setup completed"
}

# =============================================================================
# Systemd Service Setup
# =============================================================================

create_systemd_service() {
    print_header "Creating Systemd Service"
    
    cat > /etc/systemd/system/proxmox-cloud.service << EOF
[Unit]
Description=Proxmox Cloud Platform
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$APP_DIR
Environment="PATH=$VENV_DIR/bin"
EnvironmentFile=$CONFIG_DIR/.env
ExecStart=$VENV_DIR/bin/uvicorn main:app --host $HOST --port $PORT
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=proxmox-cloud

[Install]
WantedBy=multi-user.target
EOF

    # Create logrotate configuration
    cat > /etc/logrotate.d/proxmox-cloud << EOF
$LOG_DIR/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 644 $APP_USER $APP_GROUP
    sharedscripts
    postrotate
        systemctl reload proxmox-cloud > /dev/null 2>&1 || true
    endscript
}
EOF

    # Reload systemd
    systemctl daemon-reload
    
    # Enable service
    systemctl enable proxmox-cloud.service >> "$LOG_FILE" 2>&1
    
    print_success "Systemd service created"
    log "Systemd service configured"
}

# =============================================================================
# Nginx Configuration
# =============================================================================

configure_nginx() {
    print_header "Configuring Nginx"
    
    # Get server IP
    SERVER_IP=$(ip route get 1 | awk '{print $NF;exit}')
    
    cat > /etc/nginx/sites-available/proxmox-cloud << EOF
server {
    listen 80;
    listen [::]:80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # Logging
    access_log $LOG_DIR/nginx_access.log;
    error_log $LOG_DIR/nginx_error.log;
    
    # Client max body size
    client_max_body_size 100M;
    
    # Proxy settings
    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://127.0.0.1:$PORT/ws;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
    
    # Static files
    location /static {
        alias $APP_DIR/static;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
EOF

    # Enable site
    ln -sf /etc/nginx/sites-available/proxmox-cloud /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    
    # Test nginx config
    nginx -t >> "$LOG_FILE" 2>&1
    
    # Restart nginx
    systemctl restart nginx >> "$LOG_FILE" 2>&1
    systemctl enable nginx >> "$LOG_FILE" 2>&1
    
    print_success "Nginx configured"
    log "Nginx configuration completed"
}

# =============================================================================
# Firewall Configuration
# =============================================================================

configure_firewall() {
    print_header "Configuring Firewall"
    
    # Configure UFW
    ufw --force reset >> "$LOG_FILE" 2>&1
    ufw default deny incoming >> "$LOG_FILE" 2>&1
    ufw default allow outgoing >> "$LOG_FILE" 2>&1
    
    # Allow SSH
    ufw allow 22/tcp >> "$LOG_FILE" 2>&1
    
    # Allow HTTP/HTTPS
    ufw allow 80/tcp >> "$LOG_FILE" 2>&1
    ufw allow 443/tcp >> "$LOG_FILE" 2>&1
    
    # Allow application port (if needed)
    ufw allow $PORT/tcp >> "$LOG_FILE" 2>&1
    
    # Enable firewall
    echo "y" | ufw enable >> "$LOG_FILE" 2>&1
    
    # Configure fail2ban
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = 22
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[proxmox-auth]
enabled = true
port = http,https
filter = proxmox-auth
logpath = $LOG_DIR/*.log
maxretry = 5
EOF

    # Create fail2ban filter for application
    cat > /etc/fail2ban/filter.d/proxmox-auth.conf << EOF
[Definition]
failregex = ^.*Failed login attempt from <HOST>.*$
ignoreregex =
EOF

    systemctl restart fail2ban >> "$LOG_FILE" 2>&1
    systemctl enable fail2ban >> "$LOG_FILE" 2>&1
    
    print_success "Firewall configured"
    log "Firewall configuration completed"
}

# =============================================================================
# SSL Certificate (Optional)
# =============================================================================

setup_ssl() {
    print_header "Setting up SSL Certificate"
    
    read -p "Do you want to set up SSL with Let's Encrypt? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        read -p "Enter your domain name: " DOMAIN_NAME
        
        if [ -n "$DOMAIN_NAME" ]; then
            # Update nginx config with domain
            sed -i "s/server_name _;/server_name $DOMAIN_NAME;/" /etc/nginx/sites-available/proxmox-cloud
            
            # Obtain certificate
            certbot --nginx -d "$DOMAIN_NAME" --non-interactive --agree-tos --email admin@"$DOMAIN_NAME" >> "$LOG_FILE" 2>&1
            
            # Setup auto-renewal
            echo "0 0,12 * * * root certbot renew --quiet" > /etc/cron.d/certbot-renew
            
            print_success "SSL certificate installed for $DOMAIN_NAME"
            log "SSL certificate installed for $DOMAIN_NAME"
        else
            print_warning "No domain provided. Skipping SSL setup."
        fi
    else
        print_info "Skipping SSL setup. You can set it up later with: certbot --nginx"
    fi
}

# =============================================================================
# Monitoring and Health Checks
# =============================================================================

setup_monitoring() {
    print_header "Setting up Monitoring"
    
    # Create health check script
    cat > /usr/local/bin/proxmox-health-check.sh << 'EOF'
#!/bin/bash
SERVICE="proxmox-cloud"
if systemctl is-active --quiet $SERVICE; then
    echo "✓ $SERVICE is running"
    exit 0
else
    echo "✗ $SERVICE is not running"
    systemctl restart $SERVICE
    exit 1
fi
EOF
    
    chmod +x /usr/local/bin/proxmox-health-check.sh
    
    # Add to crontab
    echo "*/5 * * * * root /usr/local/bin/proxmox-health-check.sh >> /var/log/proxmox-cloud/health-check.log 2>&1" > /etc/cron.d/proxmox-health-check
    
    print_success "Monitoring configured"
    log "Monitoring setup completed"
}

# =============================================================================
# Backup Configuration
# =============================================================================

setup_backup() {
    print_header "Setting up Backup"
    
    mkdir -p /var/backups/proxmox-cloud
    
    cat > /etc/cron.daily/proxmox-backup << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/proxmox-cloud"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup database
pg_dump -U proxmox_user proxmox_cloud > "$BACKUP_DIR/db_$DATE.sql"

# Backup application files
tar -czf "$BACKUP_DIR/app_$DATE.tar.gz" -C /opt proxmox-cloud

# Backup configuration
tar -czf "$BACKUP_DIR/config_$DATE.tar.gz" -C /etc proxmox-cloud

# Remove backups older than 30 days
find $BACKUP_DIR -type f -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -type f -name "*.tar.gz" -mtime +30 -delete

echo "Backup completed for $DATE" >> /var/log/proxmox-cloud/backup.log
EOF
    
    chmod +x /etc/cron.daily/proxmox-backup
    
    print_success "Backup configured"
    log "Backup setup completed"
}

# =============================================================================
# Start Application
# =============================================================================

start_application() {
    print_header "Starting Proxmox Cloud Platform"
    
    # Start the service
    systemctl start proxmox-cloud
    
    # Wait for service to start
    sleep 5
    
    # Check if service is running
    if systemctl is-active --quiet proxmox-cloud; then
        print_success "Proxmox Cloud Platform is running"
    else
        print_error "Failed to start Proxmox Cloud Platform"
        journalctl -u proxmox-cloud -n 50 --no-pager
        exit 1
    fi
    
    log "Application started successfully"
}

# =============================================================================
# Installation Summary
# =============================================================================

show_summary() {
    print_header "Installation Complete!"
    
    SERVER_IP=$(ip route get 1 | awk '{print $NF;exit}')
    
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════════════════════════╗"
    echo "║              Proxmox Cloud Platform - Installation Complete          ║"
    echo "╚═══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "${BLUE}Application URLs:${NC}"
    echo "  - http://$SERVER_IP"
    echo "  - http://localhost:$PORT"
    echo ""
    
    echo -e "${BLUE}Login Credentials:${NC}"
    echo "  - Username: admin"
    echo "  - Password: Admin@123456"
    echo "  - Role: OWNER"
    echo ""
    
    echo -e "${BLUE}Admin Panel URLs:${NC}"
    echo "  - Dashboard: http://$SERVER_IP/admin"
    echo "  - Payment Gateways: http://$SERVER_IP/admin/payment-gateways"
    echo "  - Role Management: http://$SERVER_IP/admin/roles"
    echo ""
    
    echo -e "${BLUE}Service Management:${NC}"
    echo "  - Start:   sudo systemctl start proxmox-cloud"
    echo "  - Stop:    sudo systemctl stop proxmox-cloud"
    echo "  - Restart: sudo systemctl restart proxmox-cloud"
    echo "  - Status:  sudo systemctl status proxmox-cloud"
    echo "  - Logs:    sudo journalctl -u proxmox-cloud -f"
    echo ""
    
    echo -e "${BLUE}Log Files:${NC}"
    echo "  - Application: $LOG_DIR/"
    echo "  - Nginx:       /var/log/nginx/"
    echo "  - PostgreSQL:  /var/log/postgresql/"
    echo ""
    
    echo -e "${BLUE}Configuration Files:${NC}"
    echo "  - App Config:   $CONFIG_DIR/.env"
    echo "  - Nginx:        /etc/nginx/sites-available/proxmox-cloud"
    echo "  - Systemd:      /etc/systemd/system/proxmox-cloud.service"
    echo ""
    
    echo -e "${BLUE}Backup Locations:${NC}"
    echo "  - Database: /var/backups/proxmox-cloud/"
    echo "  - Files:    /var/backups/proxmox-cloud/"
    echo ""
    
    echo -e "${YELLOW}Important Notes:${NC}"
    echo "  • Change the default password immediately after first login"
    echo "  • Configure payment gateways from the admin panel"
    echo "  • Set up SSL certificate for production use"
    echo "  • Review and adjust firewall rules as needed"
    echo "  • Check logs regularly for any issues"
    echo ""
    
    echo -e "${GREEN}Thank you for installing Proxmox Cloud Platform!${NC}"
}

# =============================================================================
# Uninstall Function
# =============================================================================

uninstall() {
    print_header "Uninstalling Proxmox Cloud Platform"
    
    read -p "Are you sure you want to uninstall? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Uninstall cancelled"
        exit 0
    fi
    
    # Stop services
    systemctl stop proxmox-cloud 2>/dev/null || true
    systemctl disable proxmox-cloud 2>/dev/null || true
    
    # Remove systemd service
    rm -f /etc/systemd/system/proxmox-cloud.service
    systemctl daemon-reload
    
    # Remove nginx config
    rm -f /etc/nginx/sites-available/proxmox-cloud
    rm -f /etc/nginx/sites-enabled/proxmox-cloud
    systemctl reload nginx
    
    # Remove application files
    rm -rf "$APP_DIR" "$DATA_DIR" "$CONFIG_DIR"
    
    # Remove logs
    rm -rf "$LOG_DIR"
    
    # Remove user
    userdel -r "$APP_USER" 2>/dev/null || true
    
    # Remove cron jobs
    rm -f /etc/cron.d/proxmox-health-check
    rm -f /etc/cron.daily/proxmox-backup
    rm -f /etc/cron.daily/proxmox-db-backup
    
    # Ask about removing database
    read -p "Remove PostgreSQL database? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo -u postgres psql -c "DROP DATABASE IF EXISTS proxmox_cloud;" 2>/dev/null || true
        sudo -u postgres psql -c "DROP USER IF EXISTS proxmox_user;" 2>/dev/null || true
    fi
    
    print_success "Uninstall completed"
    log "Application uninstalled"
}

# =============================================================================
# Main Installation Flow
# =============================================================================

main() {
    # Check if uninstall flag is set
    if [[ "$1" == "uninstall" ]]; then
        uninstall
        exit 0
    fi
    
    print_header "Proxmox Cloud Platform - Automatic Installation"
    
    echo "This script will install:"
    echo "  • Python 3 and required packages"
    echo "  • PostgreSQL database"
    echo "  • Redis cache"
    echo "  • Nginx web server"
    echo "  • Systemd service"
    echo "  • Firewall configuration"
    echo ""
    echo "The application will be installed in: $APP_DIR"
    echo ""
    
    read -p "Continue with installation? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Installation cancelled"
        exit 0
    fi
    
    # Create log file
    create_log_file
    
    # Run installation steps
    check_root
    check_os
    check_requirements
    update_system
    install_dependencies
    create_user
    setup_postgresql
    setup_redis
    setup_application
    create_systemd_service
    configure_nginx
    configure_firewall
    setup_ssl
    setup_monitoring
    setup_backup
    start_application
    
    # Show completion summary
    show_summary
    
    log "Installation completed successfully"
}

# =============================================================================
# Run main function with arguments
# =============================================================================

main "$@"