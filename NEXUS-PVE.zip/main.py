"""
Proxmox Cloud Platform - Complete Single File Application
Enterprise Cloud VPS Hosting Platform with Role-Based Access Control
"""

from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, status, UploadFile, File, Form, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON, BigInteger, DECIMAL, func, and_, or_, desc
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session
from sqlalchemy.dialects.postgresql import UUID, JSONB
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
import asyncio
import uuid
import secrets
import hashlib
import hmac
import json
import os
import re
import qrcode
from io import BytesIO
import base64
import httpx
import requests
import logging
from decimal import Decimal
import pyotp
import stripe
import paypalrestsdk
from web3 import Web3
from proxmoxer import ProxmoxAPI
import redis.asyncio as redis
from datetime import datetime, timedelta
import bcrypt

# ============ Configuration ============

class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://postgres:password@localhost:5432/proxmox_cloud")
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-" + secrets.token_hex(32))
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    OWNER_EMAIL: str = os.getenv("OWNER_EMAIL", "owner@proxmoxcloud.com")
    OWNER_PASSWORD: str = os.getenv("OWNER_PASSWORD", "Owner@123456")
    OWNER_USERNAME: str = os.getenv("OWNER_USERNAME", "owner")
    DEFAULT_COIN_RATE: float = 1.0
    HOURLY_BILLING_INTERVAL: int = 3600
    GRACE_PERIOD_DAYS: int = 7
    PANEL_NAME: str = "Proxmox Cloud Platform"
    PRIMARY_COLOR: str = "#3B82F6"
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")

settings = Settings()

# ============ Database Setup ============

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ============ Role Definitions ============

class RolePermissions:
    """Define permissions for each role"""
    
    ROLES = {
        "OWNER": {
            "level": 100,
            "permissions": [
                "manage_all", "delete_platform", "manage_owners", "manage_co_owners",
                "manage_ceo", "manage_managers", "manage_admins", "manage_members",
                "view_all_users", "edit_all_users", "delete_any_user", "view_all_vps",
                "manage_all_vps", "view_all_transactions", "manage_all_nodes",
                "manage_all_payment_gateways", "view_all_stats", "manage_license",
                "manage_branding", "manage_system_settings", "view_audit_logs"
            ]
        },
        "CO_OWNER": {
            "level": 90,
            "permissions": [
                "manage_co_owners", "manage_ceo", "manage_managers", "manage_admins",
                "manage_members", "view_all_users", "edit_all_users", "delete_any_user",
                "view_all_vps", "manage_all_vps", "view_all_transactions",
                "manage_all_nodes", "manage_all_payment_gateways", "view_all_stats",
                "manage_branding", "view_audit_logs"
            ]
        },
        "CEO": {
            "level": 80,
            "permissions": [
                "manage_ceo", "manage_managers", "manage_admins", "manage_members",
                "view_all_users", "edit_all_users", "view_all_vps", "manage_all_vps",
                "view_all_transactions", "manage_all_nodes", "view_all_stats",
                "view_audit_logs", "manage_payment_gateways"
            ]
        },
        "MANAGER": {
            "level": 70,
            "permissions": [
                "manage_managers", "manage_admins", "manage_members", "view_all_users",
                "edit_users", "view_all_vps", "manage_vps", "view_all_transactions",
                "manage_nodes", "view_stats", "view_audit_logs"
            ]
        },
        "MAIN_ADMIN": {
            "level": 60,
            "permissions": [
                "manage_admins", "manage_members", "view_all_users", "edit_users",
                "view_all_vps", "manage_vps", "view_transactions", "view_stats"
            ]
        },
        "ADMIN": {
            "level": 50,
            "permissions": [
                "manage_members", "view_users", "view_vps", "manage_own_vps",
                "view_own_transactions", "view_basic_stats"
            ]
        },
        "MEMBER": {
            "level": 10,
            "permissions": [
                "view_own_profile", "manage_own_vps", "view_own_transactions",
                "deposit_funds", "use_coupons", "view_own_stats"
            ]
        }
    }
    
    @classmethod
    def has_permission(cls, role: str, permission: str) -> bool:
        if role not in cls.ROLES:
            return False
        return permission in cls.ROLES[role]["permissions"]
    
    @classmethod
    def get_role_level(cls, role: str) -> int:
        return cls.ROLES.get(role, {}).get("level", 0)
    
    @classmethod
    def can_manage_role(cls, manager_role: str, target_role: str) -> bool:
        """Check if manager_role can manage target_role"""
        return cls.get_role_level(manager_role) > cls.get_role_level(target_role)

# ============ Database Models ============

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(String(36), unique=True, default=lambda: str(uuid.uuid4()))
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(String(50), default="MEMBER")  # OWNER, CO_OWNER, CEO, MANAGER, MAIN_ADMIN, ADMIN, MEMBER
    is_active = Column(Boolean, default=True)
    coins_balance = Column(DECIMAL(20, 8), default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime)
    
    # 2FA
    twofa_secret = Column(String(255))
    twofa_enabled = Column(Boolean, default=False)
    twofa_backup_codes = Column(JSON, default=list)
    
    # Referral
    referral_code = Column(String(50), unique=True)
    referred_by = Column(Integer, ForeignKey("users.id"))
    
    # Restrictions
    max_vps = Column(Integer, default=50)
    max_bandwidth = Column(BigInteger, default=10000)  # GB
    allowed_os_templates = Column(JSON, default=list)
    
    # Relationships
    vps_instances = relationship("VPSInstance", back_populates="owner")
    transactions = relationship("Transaction", back_populates="user")
    api_keys = relationship("APIKey", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")
    
    creator = relationship("User", remote_side=[id], backref="created_users")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String(100))
    resource_type = Column(String(50))
    resource_id = Column(String(100))
    details = Column(JSON)
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="audit_logs")

class PaymentGatewayConfig(Base):
    __tablename__ = "payment_gateway_configs"
    id = Column(Integer, primary_key=True, index=True)
    gateway_name = Column(String(50), unique=True, nullable=False)
    display_name = Column(String(100))
    is_enabled = Column(Boolean, default=False)
    is_test_mode = Column(Boolean, default=True)
    config = Column(JSONB, default={})
    credentials = Column(JSONB, default={})  # Encrypted credentials
    supported_currencies = Column(JSON, default=["USD"])
    supported_coins = Column(JSON, default=[])  # For crypto
    min_deposit = Column(DECIMAL(20, 8), default=1.0)
    max_deposit = Column(DECIMAL(20, 8), default=10000.0)
    fee_percentage = Column(DECIMAL(5, 2), default=0.0)
    fee_fixed = Column(DECIMAL(20, 8), default=0.0)
    processing_time = Column(String(50), default="instant")
    instructions = Column(Text)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = Column(Integer, ForeignKey("users.id"))

class Node(Base):
    __tablename__ = "nodes"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    hostname = Column(String(255), nullable=False)
    api_url = Column(String(500), nullable=False)
    api_token = Column(String(500))
    is_active = Column(Boolean, default=True)
    is_free_node = Column(Boolean, default=False)
    location = Column(String(100))
    location_code = Column(String(10))
    total_cpu = Column(Integer, default=0)
    used_cpu = Column(Integer, default=0)
    total_ram = Column(BigInteger, default=0)
    used_ram = Column(BigInteger, default=0)
    total_disk = Column(BigInteger, default=0)
    used_disk = Column(BigInteger, default=0)
    current_vps = Column(Integer, default=0)
    status = Column(String(50), default="online")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    vps_instances = relationship("VPSInstance", back_populates="node")

class VPSPlan(Base):
    __tablename__ = "vps_plans"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    cpu_cores = Column(Integer, nullable=False)
    ram_mb = Column(Integer, nullable=False)
    disk_gb = Column(Integer, nullable=False)
    bandwidth_gb = Column(Integer, default=1000)
    hourly_price = Column(DECIMAL(20, 8), nullable=False)
    monthly_price = Column(DECIMAL(20, 8))
    yearly_price = Column(DECIMAL(20, 8))
    is_active = Column(Boolean, default=True)
    is_featured = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class VPSInstance(Base):
    __tablename__ = "vps_instances"
    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(String(36), unique=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(Integer, ForeignKey("users.id"))
    node_id = Column(Integer, ForeignKey("nodes.id"))
    plan_id = Column(Integer, ForeignKey("vps_plans.id"))
    name = Column(String(100))
    ip_address = Column(String(45))
    os_template = Column(String(50))
    status = Column(String(50), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    suspended_at = Column(DateTime)

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    transaction_id = Column(String(100), unique=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    amount = Column(DECIMAL(20, 8))
    coin_amount = Column(DECIMAL(20, 8))
    type = Column(String(50))
    status = Column(String(50), default="pending")
    payment_method = Column(String(50))
    gateway_name = Column(String(50))
    gateway_transaction_id = Column(String(255))
    fee_amount = Column(DECIMAL(20, 8), default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    user = relationship("User", back_populates="transactions")

class APIKey(Base):
    __tablename__ = "api_keys"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    key = Column(String(64), unique=True, nullable=False)
    name = Column(String(100))
    permissions = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    last_used = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="api_keys")

class Coupon(Base):
    __tablename__ = "coupons"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    discount_type = Column(String(20))
    discount_value = Column(DECIMAL(20, 8))
    min_purchase = Column(DECIMAL(20, 8), default=0)
    max_discount = Column(DECIMAL(20, 8))
    max_uses = Column(Integer, default=1)
    used_count = Column(Integer, default=0)
    per_user_limit = Column(Integer, default=1)
    applicable_plans = Column(JSON, default=[])
    start_date = Column(DateTime)
    expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    created_by = Column(Integer, ForeignKey("users.id"))

class SystemSettings(Base):
    __tablename__ = "system_settings"
    id = Column(Integer, primary_key=True, index=True)
    setting_key = Column(String(100), unique=True, nullable=False)
    setting_value = Column(JSONB)
    setting_type = Column(String(50))
    description = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class BrandingSettings(Base):
    __tablename__ = "branding_settings"
    id = Column(Integer, primary_key=True, index=True)
    panel_name = Column(String(100), default="Proxmox Cloud Platform")
    panel_logo = Column(String(500))
    panel_favicon = Column(String(500))
    primary_color = Column(String(20), default="#3B82F6")
    secondary_color = Column(String(20), default="#10B981")
    accent_color = Column(String(20), default="#EF4444")
    login_background = Column(String(500))
    footer_text = Column(String(500))
    custom_css = Column(Text)
    custom_js = Column(Text)

# Create tables
Base.metadata.create_all(bind=engine)

# ============ Security ============

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = int(payload.get("sub"))
        user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def require_permission(permission: str):
    """Decorator to check user permissions"""
    async def permission_dependency(current_user: User = Depends(get_current_user)):
        if not RolePermissions.has_permission(current_user.role, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission denied. Required: {permission}"
            )
        return current_user
    return permission_dependency

def require_role(min_role: str):
    """Decorator to check minimum role level"""
    async def role_dependency(current_user: User = Depends(get_current_user)):
        if RolePermissions.get_role_level(current_user.role) < RolePermissions.get_role_level(min_role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role {min_role} or higher required"
            )
        return current_user
    return role_dependency

async def log_audit(user_id: int, action: str, resource_type: str, resource_id: str, details: dict, ip: str, user_agent: str, db: Session):
    """Log user action for audit"""
    audit = AuditLog(
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details,
        ip_address=ip,
        user_agent=user_agent
    )
    db.add(audit)
    db.commit()

def generate_referral_code():
    return secrets.token_urlsafe(8)[:12]

def generate_transaction_id():
    return f"TXN_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{secrets.token_hex(4).upper()}"

# ============ Pydantic Schemas ============

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    full_name: Optional[str] = None
    password: str
    role: str = "MEMBER"
    referral_code: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    uuid: str
    username: str
    email: str
    full_name: Optional[str]
    role: str
    coins_balance: float
    is_active: bool
    referral_code: str
    created_at: datetime

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None
    max_vps: Optional[int] = None

class PaymentGatewayCreate(BaseModel):
    gateway_name: str
    display_name: str
    is_enabled: bool = False
    is_test_mode: bool = True
    config: Dict[str, Any] = {}
    credentials: Dict[str, Any] = {}
    supported_currencies: List[str] = ["USD"]
    supported_coins: List[str] = []
    min_deposit: float = 1.0
    max_deposit: float = 10000.0
    fee_percentage: float = 0.0
    fee_fixed: float = 0.0
    instructions: Optional[str] = None

class PaymentGatewayResponse(BaseModel):
    id: int
    gateway_name: str
    display_name: str
    is_enabled: bool
    is_test_mode: bool
    config: Dict[str, Any]
    supported_currencies: List[str]
    supported_coins: List[str]
    min_deposit: float
    max_deposit: float
    fee_percentage: float
    fee_fixed: float
    instructions: Optional[str]
    sort_order: int

class VPSCreate(BaseModel):
    plan_id: int
    name: str
    os_template: str

class DepositRequest(BaseModel):
    amount: float
    gateway_name: str
    currency: str = "USD"

# ============ FastAPI App ============

app = FastAPI(title="Proxmox Cloud Platform", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============ HTML Templates (Embedded) ============

ADMIN_PAYMENT_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Gateway Configuration - Proxmox Cloud</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <nav class="bg-gray-800 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <i class="fas fa-credit-card fa-2x"></i>
                    <span class="ml-2 font-bold text-xl">Payment Gateway Configuration</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/admin" class="hover:text-gray-300">Back to Dashboard</a>
                    <button onclick="logout()" class="bg-red-600 px-4 py-2 rounded-lg hover:bg-red-700">Logout</button>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="mb-8">
            <h1 class="text-3xl font-bold">Payment Gateway Management</h1>
            <p class="text-gray-600">Configure and manage all payment gateways for your platform</p>
        </div>
        
        <!-- Gateway List -->
        <div id="gatewaysList" class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Gateways will be loaded here -->
        </div>
        
        <!-- Add New Gateway Modal -->
        <div id="addGatewayModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-lg bg-white">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold">Add New Payment Gateway</h3>
                    <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <form id="addGatewayForm">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold mb-2">Gateway Name</label>
                            <input type="text" id="gateway_name" class="w-full p-2 border rounded" required>
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Display Name</label>
                            <input type="text" id="display_name" class="w-full p-2 border rounded" required>
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Minimum Deposit</label>
                            <input type="number" id="min_deposit" class="w-full p-2 border rounded" value="1.0">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Maximum Deposit</label>
                            <input type="number" id="max_deposit" class="w-full p-2 border rounded" value="10000">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Fee Percentage (%)</label>
                            <input type="number" id="fee_percentage" class="w-full p-2 border rounded" value="0">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Fixed Fee</label>
                            <input type="number" id="fee_fixed" class="w-full p-2 border rounded" value="0">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Supported Currencies</label>
                            <input type="text" id="supported_currencies" placeholder="USD,EUR,GBP" class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Supported Coins (Crypto)</label>
                            <input type="text" id="supported_coins" placeholder="BTC,ETH,USDT" class="w-full p-2 border rounded">
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Configuration (JSON)</label>
                        <textarea id="config" rows="4" class="w-full p-2 border rounded font-mono text-sm">{}</textarea>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Credentials (Encrypted)</label>
                        <textarea id="credentials" rows="4" class="w-full p-2 border rounded font-mono text-sm">{}</textarea>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Instructions</label>
                        <textarea id="instructions" rows="3" class="w-full p-2 border rounded"></textarea>
                    </div>
                    
                    <div class="mt-4 flex items-center space-x-4">
                        <label class="flex items-center">
                            <input type="checkbox" id="is_enabled" class="mr-2"> Enable Gateway
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" id="is_test_mode" class="mr-2" checked> Test Mode
                        </label>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeModal()" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Add Gateway</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Edit Gateway Modal -->
        <div id="editGatewayModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-lg bg-white">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold">Edit Payment Gateway</h3>
                    <button onclick="closeEditModal()" class="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <form id="editGatewayForm">
                    <input type="hidden" id="edit_gateway_id">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold mb-2">Display Name</label>
                            <input type="text" id="edit_display_name" class="w-full p-2 border rounded" required>
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Minimum Deposit</label>
                            <input type="number" id="edit_min_deposit" class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Maximum Deposit</label>
                            <input type="number" id="edit_max_deposit" class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Fee Percentage</label>
                            <input type="number" id="edit_fee_percentage" class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Fixed Fee</label>
                            <input type="number" id="edit_fee_fixed" class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-bold mb-2">Supported Currencies</label>
                            <input type="text" id="edit_supported_currencies" class="w-full p-2 border rounded">
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Configuration (JSON)</label>
                        <textarea id="edit_config" rows="4" class="w-full p-2 border rounded font-mono text-sm"></textarea>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Credentials (Encrypted)</label>
                        <textarea id="edit_credentials" rows="4" class="w-full p-2 border rounded font-mono text-sm"></textarea>
                    </div>
                    
                    <div class="mt-4">
                        <label class="block text-sm font-bold mb-2">Instructions</label>
                        <textarea id="edit_instructions" rows="3" class="w-full p-2 border rounded"></textarea>
                    </div>
                    
                    <div class="mt-4 flex items-center space-x-4">
                        <label class="flex items-center">
                            <input type="checkbox" id="edit_is_enabled" class="mr-2"> Enable Gateway
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" id="edit_is_test_mode" class="mr-2"> Test Mode
                        </label>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeEditModal()" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Update Gateway</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="mt-6">
            <button onclick="openModal()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-plus mr-2"></i> Add Payment Gateway
            </button>
        </div>
    </div>
    
    <script>
        const token = localStorage.getItem('token');
        const userRole = localStorage.getItem('user_role');
        
        if (!token) window.location.href = '/login';
        
        // Check if user has permission to manage payment gateways
        const allowedRoles = ['OWNER', 'CO_OWNER', 'CEO', 'MANAGER', 'MAIN_ADMIN'];
        if (!allowedRoles.includes(userRole)) {
            window.location.href = '/dashboard';
        }
        
        async function loadGateways() {
            const response = await fetch('/api/admin/payment-gateways', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const gateways = await response.json();
            
            const container = document.getElementById('gatewaysList');
            container.innerHTML = gateways.map(gw => `
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div class="p-4 ${gw.is_enabled ? 'border-l-4 border-green-500' : 'border-l-4 border-red-500'}">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="text-lg font-bold">${gw.display_name || gw.gateway_name}</h3>
                                <p class="text-sm text-gray-500">${gw.gateway_name}</p>
                            </div>
                            <span class="px-2 py-1 rounded text-xs font-semibold ${gw.is_enabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                ${gw.is_enabled ? 'Enabled' : 'Disabled'}
                            </span>
                        </div>
                        <div class="mt-3 space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Mode:</span>
                                <span class="${gw.is_test_mode ? 'text-yellow-600' : 'text-green-600'}">
                                    ${gw.is_test_mode ? 'Test Mode' : 'Live Mode'}
                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Min Deposit:</span>
                                <span>$${gw.min_deposit}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Max Deposit:</span>
                                <span>$${gw.max_deposit}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Fee:</span>
                                <span>${gw.fee_percentage}% + $${gw.fee_fixed}</span>
                            </div>
                            ${gw.supported_currencies ? `
                            <div class="flex justify-between">
                                <span class="text-gray-600">Currencies:</span>
                                <span>${gw.supported_currencies.join(', ')}</span>
                            </div>
                            ` : ''}
                            ${gw.supported_coins && gw.supported_coins.length ? `
                            <div class="flex justify-between">
                                <span class="text-gray-600">Coins:</span>
                                <span>${gw.supported_coins.join(', ')}</span>
                            </div>
                            ` : ''}
                        </div>
                        <div class="mt-4 flex space-x-2">
                            <button onclick="testGateway(${gw.id})" class="flex-1 bg-blue-100 text-blue-600 px-3 py-1 rounded text-sm hover:bg-blue-200">
                                <i class="fas fa-flask mr-1"></i> Test
                            </button>
                            <button onclick="editGateway(${JSON.stringify(gw).replace(/"/g, '&quot;')})" class="flex-1 bg-yellow-100 text-yellow-600 px-3 py-1 rounded text-sm hover:bg-yellow-200">
                                <i class="fas fa-edit mr-1"></i> Edit
                            </button>
                            <button onclick="toggleGateway(${gw.id}, ${!gw.is_enabled})" class="flex-1 ${gw.is_enabled ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'} px-3 py-1 rounded text-sm hover:bg-opacity-75">
                                <i class="fas ${gw.is_enabled ? 'fa-ban' : 'fa-check'} mr-1"></i>
                                ${gw.is_enabled ? 'Disable' : 'Enable'}
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
        
        async function testGateway(gatewayId) {
            try {
                const response = await fetch(`/api/admin/payment-gateways/test/${gatewayId}`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                const result = await response.json();
                if (result.success) {
                    alert(`Gateway test successful! ${result.message || ''}`);
                } else {
                    alert(`Gateway test failed: ${result.error || 'Unknown error'}`);
                }
            } catch (error) {
                alert('Test failed: ' + error.message);
            }
        }
        
        async function toggleGateway(gatewayId, enable) {
            const action = enable ? 'enable' : 'disable';
            if (confirm(`Are you sure you want to ${action} this gateway?`)) {
                const response = await fetch(`/api/admin/payment-gateways/${gatewayId}/toggle`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (response.ok) {
                    loadGateways();
                } else {
                    alert('Failed to toggle gateway');
                }
            }
        }
        
        function openModal() {
            document.getElementById('addGatewayModal').classList.remove('hidden');
        }
        
        function closeModal() {
            document.getElementById('addGatewayModal').classList.add('hidden');
            document.getElementById('addGatewayForm').reset();
        }
        
        function editGateway(gateway) {
            document.getElementById('edit_gateway_id').value = gateway.id;
            document.getElementById('edit_display_name').value = gateway.display_name || '';
            document.getElementById('edit_min_deposit').value = gateway.min_deposit;
            document.getElementById('edit_max_deposit').value = gateway.max_deposit;
            document.getElementById('edit_fee_percentage').value = gateway.fee_percentage;
            document.getElementById('edit_fee_fixed').value = gateway.fee_fixed;
            document.getElementById('edit_supported_currencies').value = gateway.supported_currencies ? gateway.supported_currencies.join(',') : '';
            document.getElementById('edit_config').value = JSON.stringify(gateway.config, null, 2);
            document.getElementById('edit_credentials').value = JSON.stringify(gateway.credentials || {}, null, 2);
            document.getElementById('edit_instructions').value = gateway.instructions || '';
            document.getElementById('edit_is_enabled').checked = gateway.is_enabled;
            document.getElementById('edit_is_test_mode').checked = gateway.is_test_mode;
            
            document.getElementById('editGatewayModal').classList.remove('hidden');
        }
        
        function closeEditModal() {
            document.getElementById('editGatewayModal').classList.add('hidden');
        }
        
        document.getElementById('addGatewayForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const gatewayData = {
                gateway_name: document.getElementById('gateway_name').value,
                display_name: document.getElementById('display_name').value,
                min_deposit: parseFloat(document.getElementById('min_deposit').value),
                max_deposit: parseFloat(document.getElementById('max_deposit').value),
                fee_percentage: parseFloat(document.getElementById('fee_percentage').value),
                fee_fixed: parseFloat(document.getElementById('fee_fixed').value),
                supported_currencies: document.getElementById('supported_currencies').value.split(',').map(s => s.trim()),
                supported_coins: document.getElementById('supported_coins').value.split(',').map(s => s.trim()),
                config: JSON.parse(document.getElementById('config').value || '{}'),
                credentials: JSON.parse(document.getElementById('credentials').value || '{}'),
                instructions: document.getElementById('instructions').value,
                is_enabled: document.getElementById('is_enabled').checked,
                is_test_mode: document.getElementById('is_test_mode').checked
            };
            
            const response = await fetch('/api/admin/payment-gateways', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(gatewayData)
            });
            
            if (response.ok) {
                alert('Gateway added successfully');
                closeModal();
                loadGateways();
            } else {
                const error = await response.json();
                alert('Failed to add gateway: ' + error.detail);
            }
        });
        
        document.getElementById('editGatewayForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const gatewayId = document.getElementById('edit_gateway_id').value;
            const gatewayData = {
                display_name: document.getElementById('edit_display_name').value,
                min_deposit: parseFloat(document.getElementById('edit_min_deposit').value),
                max_deposit: parseFloat(document.getElementById('edit_max_deposit').value),
                fee_percentage: parseFloat(document.getElementById('edit_fee_percentage').value),
                fee_fixed: parseFloat(document.getElementById('edit_fee_fixed').value),
                supported_currencies: document.getElementById('edit_supported_currencies').value.split(',').map(s => s.trim()),
                config: JSON.parse(document.getElementById('edit_config').value || '{}'),
                credentials: JSON.parse(document.getElementById('edit_credentials').value || '{}'),
                instructions: document.getElementById('edit_instructions').value,
                is_enabled: document.getElementById('edit_is_enabled').checked,
                is_test_mode: document.getElementById('edit_is_test_mode').checked
            };
            
            const response = await fetch(`/api/admin/payment-gateways/${gatewayId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(gatewayData)
            });
            
            if (response.ok) {
                alert('Gateway updated successfully');
                closeEditModal();
                loadGateways();
            } else {
                const error = await response.json();
                alert('Failed to update gateway: ' + error.detail);
            }
        });
        
        function logout() {
            localStorage.removeItem('token');
            localStorage.removeItem('user_role');
            window.location.href = '/login';
        }
        
        loadGateways();
    </script>
</body>
</html>
"""

ADMIN_ROLES_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Role Management - Proxmox Cloud</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <nav class="bg-gray-800 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <i class="fas fa-users-cog fa-2x"></i>
                    <span class="ml-2 font-bold text-xl">Role Management</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/admin" class="hover:text-gray-300">Back to Dashboard</a>
                    <button onclick="logout()" class="bg-red-600 px-4 py-2 rounded-lg hover:bg-red-700">Logout</button>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="mb-8">
            <h1 class="text-3xl font-bold">Role-Based Access Control</h1>
            <p class="text-gray-600">Manage user roles and permissions</p>
        </div>
        
        <!-- Role Hierarchy -->
        <div class="bg-white rounded-lg shadow-lg mb-8">
            <div class="p-6 border-b">
                <h2 class="text-xl font-bold">Role Hierarchy</h2>
            </div>
            <div class="p-6">
                <div class="flex flex-wrap gap-4">
                    <div class="bg-red-600 text-white px-6 py-3 rounded-lg">OWNER (Level 100)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-orange-600 text-white px-6 py-3 rounded-lg">CO-OWNER (Level 90)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-yellow-600 text-white px-6 py-3 rounded-lg">CEO (Level 80)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-green-600 text-white px-6 py-3 rounded-lg">MANAGER (Level 70)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-blue-600 text-white px-6 py-3 rounded-lg">MAIN ADMIN (Level 60)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-indigo-600 text-white px-6 py-3 rounded-lg">ADMIN (Level 50)</div>
                    <i class="fas fa-arrow-right text-2xl text-gray-400 self-center"></i>
                    <div class="bg-gray-600 text-white px-6 py-3 rounded-lg">MEMBER (Level 10)</div>
                </div>
            </div>
        </div>
        
        <!-- User Management -->
        <div class="bg-white rounded-lg shadow-lg">
            <div class="p-6 border-b flex justify-between items-center">
                <h2 class="text-xl font-bold">Users</h2>
                <button onclick="openAddUserModal()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-user-plus mr-2"></i> Add User
                </button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Coins Balance</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersList" class="divide-y divide-gray-200"></tbody>
                </table>
            </div>
        </div>
        
        <!-- Role Permissions -->
        <div class="bg-white rounded-lg shadow-lg mt-8">
            <div class="p-6 border-b">
                <h2 class="text-xl font-bold">Role Permissions</h2>
            </div>
            <div class="p-6">
                <div id="permissionsView"></div>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div id="addUserModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-lg bg-white">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-bold">Add New User</h3>
                <button onclick="closeAddUserModal()" class="text-gray-500 hover:text-gray-700">&times;</button>
            </div>
            <form id="addUserForm">
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2">Username</label>
                    <input type="text" id="new_username" class="w-full p-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2">Email</label>
                    <input type="email" id="new_email" class="w-full p-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2">Full Name</label>
                    <input type="text" id="new_fullname" class="w-full p-2 border rounded">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2">Password</label>
                    <input type="password" id="new_password" class="w-full p-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2">Role</label>
                    <select id="new_role" class="w-full p-2 border rounded" id="new_role_select">
                        <option value="MEMBER">MEMBER</option>
                        <option value="ADMIN">ADMIN</option>
                        <option value="MAIN_ADMIN">MAIN ADMIN</option>
                        <option value="MANAGER">MANAGER</option>
                        <option value="CEO">CEO</option>
                        <option value="CO_OWNER">CO-OWNER</option>
                        <option value="OWNER">OWNER</option>
                    </select>
                </div>
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="closeAddUserModal()" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Add User</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        const token = localStorage.getItem('token');
        const userRole = localStorage.getItem('user_role');
        
        if (!token) window.location.href = '/login';
        
        // Check if user has permission to manage roles
        const allowedRoles = ['OWNER', 'CO_OWNER', 'CEO', 'MANAGER'];
        if (!allowedRoles.includes(userRole)) {
            window.location.href = '/dashboard';
        }
        
        async function loadUsers() {
            const response = await fetch('/api/admin/users', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const users = await response.json();
            
            const tbody = document.getElementById('usersList');
            tbody.innerHTML = users.map(user => `
                <tr>
                    <td class="px-6 py-4">
                        <div>
                            <div class="font-medium">${user.username}</div>
                            <div class="text-sm text-gray-500">${user.email}</div>
                        </div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded text-xs font-semibold ${getRoleColor(user.role)}">
                            ${user.role}
                        </span>
                    </td>
                    <td class="px-6 py-4">${user.coins_balance} coins</td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded text-xs ${user.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                            ${user.is_active ? 'Active' : 'Disabled'}
                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex space-x-2">
                            <button onclick="editUserRole(${user.id}, '${user.role}')" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="toggleUserStatus(${user.id}, ${!user.is_active})" class="text-yellow-600 hover:text-yellow-800">
                                <i class="fas ${user.is_active ? 'fa-ban' : 'fa-check'}"></i>
                            </button>
                            ${user.role !== 'OWNER' ? `<button onclick="deleteUser(${user.id})" class="text-red-600 hover:text-red-800">
                                <i class="fas fa-trash"></i>
                            </button>` : ''}
                        </div>
                    </td>
                </tr>
            `).join('');
        }
        
        function getRoleColor(role) {
            const colors = {
                'OWNER': 'bg-red-100 text-red-800',
                'CO_OWNER': 'bg-orange-100 text-orange-800',
                'CEO': 'bg-yellow-100 text-yellow-800',
                'MANAGER': 'bg-green-100 text-green-800',
                'MAIN_ADMIN': 'bg-blue-100 text-blue-800',
                'ADMIN': 'bg-indigo-100 text-indigo-800',
                'MEMBER': 'bg-gray-100 text-gray-800'
            };
            return colors[role] || 'bg-gray-100 text-gray-800';
        }
        
        async function loadPermissions() {
            const response = await fetch('/api/admin/roles/permissions', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const permissions = await response.json();
            
            const container = document.getElementById('permissionsView');
            container.innerHTML = Object.entries(permissions).map(([role, data]) => `
                <div class="mb-6">
                    <h3 class="font-bold text-lg mb-2">${role}</h3>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                        ${data.permissions.map(perm => `
                            <span class="text-sm bg-gray-100 px-2 py-1 rounded">${perm}</span>
                        `).join('')}
                    </div>
                </div>
            `).join('');
        }
        
        async function editUserRole(userId, currentRole) {
            const newRole = prompt('Enter new role (OWNER, CO_OWNER, CEO, MANAGER, MAIN_ADMIN, ADMIN, MEMBER):', currentRole);
            if (newRole && newRole !== currentRole) {
                const response = await fetch(`/api/admin/users/${userId}/role`, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ role: newRole })
                });
                
                if (response.ok) {
                    alert('Role updated successfully');
                    loadUsers();
                } else {
                    const error = await response.json();
                    alert('Failed to update role: ' + error.detail);
                }
            }
        }
        
        async function toggleUserStatus(userId, enable) {
            const action = enable ? 'enable' : 'disable';
            if (confirm(`Are you sure you want to ${action} this user?`)) {
                const response = await fetch(`/api/admin/users/${userId}/toggle-status`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                
                if (response.ok) {
                    loadUsers();
                } else {
                    alert('Failed to toggle user status');
                }
            }
        }
        
        async function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                const response = await fetch(`/api/admin/users/${userId}`, {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                
                if (response.ok) {
                    alert('User deleted successfully');
                    loadUsers();
                } else {
                    alert('Failed to delete user');
                }
            }
        }
        
        function openAddUserModal() {
            document.getElementById('addUserModal').classList.remove('hidden');
        }
        
        function closeAddUserModal() {
            document.getElementById('addUserModal').classList.add('hidden');
            document.getElementById('addUserForm').reset();
        }
        
        document.getElementById('addUserForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const userData = {
                username: document.getElementById('new_username').value,
                email: document.getElementById('new_email').value,
                full_name: document.getElementById('new_fullname').value,
                password: document.getElementById('new_password').value,
                role: document.getElementById('new_role').value
            };
            
            const response = await fetch('/api/admin/users', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });
            
            if (response.ok) {
                alert('User created successfully');
                closeAddUserModal();
                loadUsers();
            } else {
                const error = await response.json();
                alert('Failed to create user: ' + error.detail);
            }
        });
        
        function logout() {
            localStorage.removeItem('token');
            localStorage.removeItem('user_role');
            window.location.href = '/login';
        }
        
        loadUsers();
        loadPermissions();
    </script>
</body>
</html>
"""

# ============ API Routes ============

# ============ Payment Gateway Admin Routes ============

@app.get("/api/admin/payment-gateways", response_model=List[PaymentGatewayResponse])
async def get_payment_gateways(
    current_user: User = Depends(require_permission("manage_payment_gateways")),
    db: Session = Depends(get_db)
):
    """Get all payment gateway configurations"""
    gateways = db.query(PaymentGatewayConfig).order_by(PaymentGatewayConfig.sort_order).all()
    return gateways

@app.post("/api/admin/payment-gateways")
async def create_payment_gateway(
    gateway_data: PaymentGatewayCreate,
    request: Request,
    current_user: User = Depends(require_permission("manage_payment_gateways")),
    db: Session = Depends(get_db)
):
    """Create a new payment gateway configuration"""
    existing = db.query(PaymentGatewayConfig).filter(
        PaymentGatewayConfig.gateway_name == gateway_data.gateway_name
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Gateway already exists")
    
    new_gateway = PaymentGatewayConfig(
        gateway_name=gateway_data.gateway_name,
        display_name=gateway_data.display_name,
        is_enabled=gateway_data.is_enabled,
        is_test_mode=gateway_data.is_test_mode,
        config=gateway_data.config,
        credentials=gateway_data.credentials,
        supported_currencies=gateway_data.supported_currencies,
        supported_coins=gateway_data.supported_coins,
        min_deposit=gateway_data.min_deposit,
        max_deposit=gateway_data.max_deposit,
        fee_percentage=gateway_data.fee_percentage,
        fee_fixed=gateway_data.fee_fixed,
        instructions=gateway_data.instructions,
        updated_by=current_user.id
    )
    
    db.add(new_gateway)
    db.commit()
    
    # Log audit
    await log_audit(
        current_user.id, "CREATE_PAYMENT_GATEWAY", "payment_gateway",
        new_gateway.gateway_name, {"gateway": gateway_data.dict()},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "Gateway created successfully", "id": new_gateway.id}

@app.put("/api/admin/payment-gateways/{gateway_id}")
async def update_payment_gateway(
    gateway_id: int,
    gateway_data: PaymentGatewayCreate,
    request: Request,
    current_user: User = Depends(require_permission("manage_payment_gateways")),
    db: Session = Depends(get_db)
):
    """Update payment gateway configuration"""
    gateway = db.query(PaymentGatewayConfig).filter(PaymentGatewayConfig.id == gateway_id).first()
    if not gateway:
        raise HTTPException(status_code=404, detail="Gateway not found")
    
    gateway.display_name = gateway_data.display_name
    gateway.is_enabled = gateway_data.is_enabled
    gateway.is_test_mode = gateway_data.is_test_mode
    gateway.config = gateway_data.config
    gateway.credentials = gateway_data.credentials
    gateway.supported_currencies = gateway_data.supported_currencies
    gateway.supported_coins = gateway_data.supported_coins
    gateway.min_deposit = gateway_data.min_deposit
    gateway.max_deposit = gateway_data.max_deposit
    gateway.fee_percentage = gateway_data.fee_percentage
    gateway.fee_fixed = gateway_data.fee_fixed
    gateway.instructions = gateway_data.instructions
    gateway.updated_by = current_user.id
    gateway.updated_at = datetime.utcnow()
    
    db.commit()
    
    await log_audit(
        current_user.id, "UPDATE_PAYMENT_GATEWAY", "payment_gateway",
        gateway.gateway_name, {"gateway_id": gateway_id, "updates": gateway_data.dict()},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "Gateway updated successfully"}

@app.post("/api/admin/payment-gateways/{gateway_id}/toggle")
async def toggle_payment_gateway(
    gateway_id: int,
    request: Request,
    current_user: User = Depends(require_permission("manage_payment_gateways")),
    db: Session = Depends(get_db)
):
    """Enable or disable payment gateway"""
    gateway = db.query(PaymentGatewayConfig).filter(PaymentGatewayConfig.id == gateway_id).first()
    if not gateway:
        raise HTTPException(status_code=404, detail="Gateway not found")
    
    gateway.is_enabled = not gateway.is_enabled
    gateway.updated_by = current_user.id
    db.commit()
    
    await log_audit(
        current_user.id, "TOGGLE_PAYMENT_GATEWAY", "payment_gateway",
        gateway.gateway_name, {"enabled": gateway.is_enabled},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": f"Gateway {'enabled' if gateway.is_enabled else 'disabled'}", "enabled": gateway.is_enabled}

@app.post("/api/admin/payment-gateways/test/{gateway_id}")
async def test_payment_gateway(
    gateway_id: int,
    current_user: User = Depends(require_permission("manage_payment_gateways")),
    db: Session = Depends(get_db)
):
    """Test payment gateway connection"""
    gateway = db.query(PaymentGatewayConfig).filter(PaymentGatewayConfig.id == gateway_id).first()
    if not gateway:
        raise HTTPException(status_code=404, detail="Gateway not found")
    
    # Test based on gateway type
    try:
        if gateway.gateway_name == "stripe":
            if gateway.config.get("api_key"):
                stripe.api_key = gateway.config["api_key"]
                # Test by listing accounts
                stripe.Account.list(limit=1)
                return {"success": True, "message": "Stripe connection successful"}
        
        elif gateway.gateway_name == "oxapay":
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.oxapay.com/v1/status",
                    json={"apiKey": gateway.config.get("api_key"), "orderId": "test"}
                )
                if response.status_code == 200:
                    return {"success": True, "message": "OxaPay connection successful"}
        
        return {"success": True, "message": "Gateway configuration saved"}
    
    except Exception as e:
        return {"success": False, "error": str(e)}

# ============ User Management Admin Routes ============

@app.get("/api/admin/users")
async def get_all_users(
    current_user: User = Depends(require_permission("view_all_users")),
    db: Session = Depends(get_db)
):
    """Get all users (admin only)"""
    users = db.query(User).all()
    return users

@app.post("/api/admin/users")
async def create_user(
    user_data: UserCreate,
    request: Request,
    current_user: User = Depends(require_permission("manage_members")),
    db: Session = Depends(get_db)
):
    """Create a new user (admin only)"""
    # Check if user can create this role
    if not RolePermissions.can_manage_role(current_user.role, user_data.role):
        raise HTTPException(status_code=403, detail=f"Cannot create user with role {user_data.role}")
    
    existing = db.query(User).filter(
        (User.email == user_data.email) | (User.username == user_data.username)
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Email or username already registered")
    
    hashed_password = get_password_hash(user_data.password)
    referral_code = generate_referral_code()
    
    new_user = User(
        email=user_data.email,
        username=user_data.username,
        full_name=user_data.full_name,
        hashed_password=hashed_password,
        role=user_data.role,
        referral_code=referral_code,
        created_by=current_user.id
    )
    
    db.add(new_user)
    db.commit()
    
    await log_audit(
        current_user.id, "CREATE_USER", "user",
        str(new_user.id), {"username": user_data.username, "role": user_data.role},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "User created successfully", "user_id": new_user.id}

@app.put("/api/admin/users/{user_id}/role")
async def update_user_role(
    user_id: int,
    role_data: dict,
    request: Request,
    current_user: User = Depends(require_permission("manage_admins")),
    db: Session = Depends(get_db)
):
    """Update user role"""
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    new_role = role_data.get("role")
    if not new_role:
        raise HTTPException(status_code=400, detail="Role required")
    
    # Check permissions
    if not RolePermissions.can_manage_role(current_user.role, new_role):
        raise HTTPException(status_code=403, detail=f"Cannot assign role {new_role}")
    
    if not RolePermissions.can_manage_role(current_user.role, target_user.role):
        raise HTTPException(status_code=403, detail=f"Cannot modify user with role {target_user.role}")
    
    old_role = target_user.role
    target_user.role = new_role
    db.commit()
    
    await log_audit(
        current_user.id, "UPDATE_USER_ROLE", "user",
        str(user_id), {"old_role": old_role, "new_role": new_role},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "Role updated successfully"}

@app.post("/api/admin/users/{user_id}/toggle-status")
async def toggle_user_status(
    user_id: int,
    request: Request,
    current_user: User = Depends(require_permission("manage_members")),
    db: Session = Depends(get_db)
):
    """Enable or disable user"""
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if not RolePermissions.can_manage_role(current_user.role, target_user.role):
        raise HTTPException(status_code=403, detail="Cannot modify this user")
    
    target_user.is_active = not target_user.is_active
    db.commit()
    
    await log_audit(
        current_user.id, "TOGGLE_USER_STATUS", "user",
        str(user_id), {"active": target_user.is_active},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": f"User {'enabled' if target_user.is_active else 'disabled'}"}

@app.delete("/api/admin/users/{user_id}")
async def delete_user(
    user_id: int,
    request: Request,
    current_user: User = Depends(require_permission("manage_members")),
    db: Session = Depends(get_db)
):
    """Delete user"""
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if target_user.role == "OWNER":
        raise HTTPException(status_code=403, detail="Cannot delete owner")
    
    if not RolePermissions.can_manage_role(current_user.role, target_user.role):
        raise HTTPException(status_code=403, detail="Cannot delete this user")
    
    db.delete(target_user)
    db.commit()
    
    await log_audit(
        current_user.id, "DELETE_USER", "user",
        str(user_id), {"username": target_user.username},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "User deleted successfully"}

@app.get("/api/admin/roles/permissions")
async def get_role_permissions(
    current_user: User = Depends(require_permission("view_all_users")),
):
    """Get all role permissions"""
    return RolePermissions.ROLES

# ============ Auth Routes ============

@app.post("/api/auth/register")
async def register(user_data: UserCreate, request: Request, db: Session = Depends(get_db)):
    """Register new user"""
    existing = db.query(User).filter(
        (User.email == user_data.email) | (User.username == user_data.username)
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Email or username already registered")
    
    # Only admin can create non-MEMBER roles
    if user_data.role != "MEMBER":
        raise HTTPException(status_code=403, detail="Only admins can create elevated roles")
    
    hashed_password = get_password_hash(user_data.password)
    referral_code = generate_referral_code()
    
    new_user = User(
        email=user_data.email,
        username=user_data.username,
        full_name=user_data.full_name,
        hashed_password=hashed_password,
        role="MEMBER",
        referral_code=referral_code,
        coins_balance=10.0
    )
    
    if user_data.referral_code:
        referrer = db.query(User).filter(User.referral_code == user_data.referral_code).first()
        if referrer:
            new_user.referred_by = referrer.id
            referrer.coins_balance += 5.0
    
    db.add(new_user)
    db.commit()
    
    await log_audit(
        new_user.id, "REGISTER", "user",
        str(new_user.id), {"username": user_data.username},
        request.client.host, request.headers.get("user-agent", ""), db
    )
    
    return {"message": "User created successfully", "user_id": new_user.id}

@app.post("/api/auth/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Login user"""
    user = db.query(User).filter(
        (User.username == form_data.username) | (User.email == form_data.username)
    ).first()
    
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not user.is_active:
        raise HTTPException(status_code=401, detail="Account disabled")
    
    access_token = create_access_token({"sub": str(user.id)})
    
    user.last_login = datetime.utcnow()
    db.commit()
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "is_admin": user.role in ["OWNER", "CO_OWNER", "CEO", "MANAGER", "MAIN_ADMIN", "ADMIN"]
        }
    }

# ============ User Routes ============

@app.get("/api/users/me")
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user info"""
    return {
        "id": current_user.id,
        "uuid": current_user.uuid,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "coins_balance": float(current_user.coins_balance),
        "is_active": current_user.is_active,
        "referral_code": current_user.referral_code,
        "max_vps": current_user.max_vps,
        "created_at": current_user.created_at
    }

# ============ VPS Routes ============

@app.get("/api/vps/plans")
async def get_plans(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get available VPS plans"""
    plans = db.query(VPSPlan).filter(VPSPlan.is_active == True).order_by(VPSPlan.sort_order).all()
    return plans

@app.post("/api/vps/create")
async def create_vps(
    vps_data: VPSCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create new VPS"""
    plan = db.query(VPSPlan).filter(VPSPlan.id == vps_data.plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    if current_user.coins_balance < plan.hourly_price:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    
    # Check user's VPS limit
    user_vps_count = db.query(VPSInstance).filter(VPSInstance.user_id == current_user.id).count()
    if user_vps_count >= current_user.max_vps:
        raise HTTPException(status_code=400, detail="Maximum VPS limit reached")
    
    node = db.query(Node).filter(Node.is_active == True).first()
    if not node:
        raise HTTPException(status_code=500, detail="No available nodes")
    
    new_vps = VPSInstance(
        user_id=current_user.id,
        node_id=node.id,
        plan_id=plan.id,
        name=vps_data.name,
        os_template=vps_data.os_template,
        status="running",
        expires_at=datetime.utcnow() + timedelta(days=30)
    )
    
    db.add(new_vps)
    current_user.coins_balance -= plan.hourly_price
    db.commit()
    db.refresh(new_vps)
    
    return new_vps

@app.get("/api/vps/list")
async def list_vps(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """List user's VPS instances"""
    vps_list = db.query(VPSInstance).filter(VPSInstance.user_id == current_user.id).all()
    return vps_list

# ============ HTML Routes ============

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    return INDEX_HTML

@app.get("/login", response_class=HTMLResponse)
async def serve_login():
    return LOGIN_HTML

@app.get("/register", response_class=HTMLResponse)
async def serve_register():
    return REGISTER_HTML

@app.get("/dashboard", response_class=HTMLResponse)
async def serve_dashboard():
    return DASHBOARD_HTML

@app.get("/admin", response_class=HTMLResponse)
async def serve_admin():
    return ADMIN_HTML

@app.get("/admin/payment-gateways", response_class=HTMLResponse)
async def serve_payment_gateways():
    return ADMIN_PAYMENT_HTML

@app.get("/admin/roles", response_class=HTMLResponse)
async def serve_role_management():
    return ADMIN_ROLES_HTML

# ============ Startup ============

@app.on_event("startup")
async def startup_event():
    db = SessionLocal()
    try:
        # Create owner if not exists
        owner = db.query(User).filter(User.role == "OWNER").first()
        if not owner:
            owner_user = User(
                email=settings.OWNER_EMAIL,
                username=settings.OWNER_USERNAME,
                hashed_password=get_password_hash(settings.OWNER_PASSWORD),
                full_name="System Owner",
                role="OWNER",
                referral_code=generate_referral_code(),
                coins_balance=10000000
            )
            db.add(owner_user)
            db.commit()
            print("Owner user created")
        
        # Create default payment gateways
        default_gateways = [
            {"gateway_name": "stripe", "display_name": "Stripe", "config": {"api_key": "", "webhook_secret": ""}},
            {"gateway_name": "paypal", "display_name": "PayPal", "config": {"client_id": "", "client_secret": ""}},
            {"gateway_name": "razorpay", "display_name": "Razorpay", "config": {"key_id": "", "key_secret": ""}},
            {"gateway_name": "oxapay", "display_name": "OxaPay", "config": {"api_key": "", "callback_url": ""}},
            {"gateway_name": "crypto_btc", "display_name": "Bitcoin", "config": {"wallet": ""}, "supported_coins": ["BTC"]},
            {"gateway_name": "crypto_eth", "display_name": "Ethereum", "config": {"wallet": ""}, "supported_coins": ["ETH"]},
            {"gateway_name": "crypto_ltc", "display_name": "Litecoin", "config": {"wallet": ""}, "supported_coins": ["LTC"]},
            {"gateway_name": "crypto_usdt", "display_name": "USDT", "config": {"wallet": "", "contract_address": ""}, "supported_coins": ["USDT"]}
        ]
        
        for gw in default_gateways:
            existing = db.query(PaymentGatewayConfig).filter(PaymentGatewayConfig.gateway_name == gw["gateway_name"]).first()
            if not existing:
                new_gw = PaymentGatewayConfig(
                    gateway_name=gw["gateway_name"],
                    display_name=gw["display_name"],
                    is_enabled=False,
                    is_test_mode=True,
                    config=gw.get("config", {}),
                    supported_currencies=["USD"],
                    supported_coins=gw.get("supported_coins", []),
                    min_deposit=1.0,
                    max_deposit=10000.0
                )
                db.add(new_gw)
        
        # Create default VPS plans
        default_plans = [
            {"name": "Starter", "cpu_cores": 1, "ram_mb": 1024, "disk_gb": 25, "hourly_price": 0.01, "sort_order": 1},
            {"name": "Professional", "cpu_cores": 2, "ram_mb": 4096, "disk_gb": 80, "hourly_price": 0.03, "sort_order": 2},
            {"name": "Business", "cpu_cores": 4, "ram_mb": 8192, "disk_gb": 160, "hourly_price": 0.07, "sort_order": 3},
            {"name": "Enterprise", "cpu_cores": 8, "ram_mb": 16384, "disk_gb": 320, "hourly_price": 0.15, "sort_order": 4}
        ]
        
        for plan_data in default_plans:
            existing = db.query(VPSPlan).filter(VPSPlan.name == plan_data["name"]).first()
            if not existing:
                new_plan = VPSPlan(**plan_data)
                db.add(new_plan)
        
        db.commit()
        print("=" * 50)
        print("Proxmox Cloud Platform Started Successfully!")
        print(f"Owner Login: {settings.OWNER_USERNAME} / {settings.OWNER_PASSWORD}")
        print(f"Open http://localhost:8000 to access the platform")
        print("=" * 50)
        
    finally:
        db.close()

# ============ Main Execution ============

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)